/*
In the real design, the "rows" are columns, and the "columns" are rows (from the schematic design)
I just had them switched because thats the way it was at the schematic design



 */
const int R0 = 0;
const int R1 = 1;
const int R2 = 2;
const int R3 = 3;
const int R4 = 4;
const int R5 = 5;
const int R6 = 6;
const int R7 = 7;
const int R8 = 8;
const int R9 = 9;
const int C0 = 10;
const int C1 = 11;
const int C2 = 12;
const int C3 = 13;
const int C4 = 14;
const int C5 = 15;
const int AMPGPIO = 16;
const int INPLUS = 17;
const int SCK_PIN = 18;
const int MOSI_PIN = 19;
const int MISO_PIN = 20;
const int CS_PIN = 21;
const int DC_PIN = 22;
const int RST_PIN = 26;
const int BL_GPIO = 28;
//drive pins
const int row[] = {
  R0, R1, R2, R3, R4, R5, R6, R7, R8, R9
};
//sense pins
const int col[] = {
  C0, C1, C2, C3, C4, C5
}; 

void setup() {
  Serial.begin(115200);
  
  //rows
    pinMode(R0, OUTPUT);
    pinMode(R1, OUTPUT);
    pinMode(R2, OUTPUT);
    pinMode(R3, OUTPUT);
    pinMode(R4, OUTPUT);
    pinMode(R5, OUTPUT);
    pinMode(R6, OUTPUT);
    pinMode(R7, OUTPUT);
    pinMode(R8, OUTPUT);
    pinMode(R9, OUTPUT);
    digitalWrite(R0, HIGH);
    digitalWrite(R1, HIGH);
    digitalWrite(R2, HIGH);
    digitalWrite(R3, HIGH);
    digitalWrite(R4, HIGH);
    digitalWrite(R5, HIGH);
    digitalWrite(R6, HIGH);
    digitalWrite(R7, HIGH);
    digitalWrite(R8, HIGH);
    digitalWrite(R9, HIGH);
  
  //columns
    pinMode(C0, INPUT_PULLUP);
    pinMode(C1, INPUT_PULLUP);
    pinMode(C2, INPUT_PULLUP);
    pinMode(C3, INPUT_PULLUP);
    pinMode(C4, INPUT_PULLUP);
    pinMode(C5, INPUT_PULLUP);

    pinMode(AMPGPIO, OUTPUT);
    pinMode(BL_GPIO, OUTPUT);
  
}

void loop() {
    testscan();
    flashAnzan();
}
void flashAnzan(){
  Serial.begin(9600);
  int FAtime;
  int FAcount;
  int FAdigits; //cant be less than 0, cant be greater than 7
  int FAnumber;
  int FAanswer;

  if(FAtime<99){
    
  } else if(FAcount>10000){
    
  } else if(FAdigits>8){
    
  }

  
  for (int a=i; i<FAcount; i++){
    FAnumber = random(pow(10, FAdigits-1), pow(10, FAdigits));
    Serial.print();
    delay(FAtime);
    FAanswer = FAanswer + FAnumber; 
    Serial.print("\033[2J\033[H");
  }
  
}

void testquestions(){
  Serial.begin(9600);
  randomSeed(analogRead(0)); 
  seed = random(0,5);
  
  int a1 = 0;
  int a2 = 0;
  int a3 = 0;
  int b1 = 0;
  int b2 = 0;
  int b3 = 0;
  int c1 = 0;
  int c2 = 0;
  int c3 = 0;
  int seed = 0;
  int var_max = 20;
  int var_min = 15;  //for now these values are okay
  bool areCollinear(int a1, int a2, int a3, int b1, int b2, int b3, int c1, int c2, int c3) 

  
  
if(seed == 0){ //find the equation of a plane with three vectors
    do{
    a1 = random(random(-(var_max), -(var_min)), random(var_min, var_max));
    a2 = random(random(-(var_max), -(var_min)), random(var_min, var_max));
    a3 = random(random(-(var_max), -(var_min)), random(var_min, var_max));
    b1 = random(random(-(var_max), -(var_min)), random(var_min, var_max));
    b2 = random(random(-(var_max), -(var_min)), random(var_min, var_max));
    b3 = random(random(-(var_max), -(var_min)), random(var_min, var_max));
    c1 = random(random(-(var_max), -(var_min)), random(var_min, var_max));
    c2 = random(random(-(var_max), -(var_min)), random(var_min, var_max));
    c3 = random(random(-(var_max), -(var_min)), random(var_min, var_max));
    } while(a1 == b1 && a2 == b2 && a3 == c3 ||
     b1 == c1 && b2 == c2 && b3 == c3 ||
     c1 == a1 && c2 == a2 && c3 == a3) //check if they are not the same 
    Serial.print("Find the equation of a 3d plane that contains the points" + \n + 
                 "("+a1+","+a2+","+a3+"),"+
                 "("+b1+","+b2+","+b3+"),"
                 "("+c1+","+c2+","+c3+")." + \n +
                 "Enter your answer in the form Ax + By + Cz = D, where" + \n 
                 "A, B, C, and D are fully simplified");
    int v1 = b1-a1;
    int v2 = b2-a2;
    int v3 = b3-a3;
    int w1 = c1-a1;
    int w2 = c2-a2;
    int w3 = c3-a3;
    int n1 = (v2)*(w3)-(v3)*(w2);
    int n2 = (v3)*(w1)-(v1)*(w3);
    int n3 = (v1)*(w2)-(v2)*(w1);
    int dotproduct_d = (a1)*(n1)+(a2)*(n2)+(a3)*(n3);
    
    String answer = String(n1) + "x" + String(n2) + "y" + String(n3) + "z=" + String(dotproduct_d);
    //check if answer has a space
    
} else {
    if(seed == 1){//find a plane with a parametric line and a point  
    
    }
}
  
  
}
void testscan(){
    for (int r=0; r<10; r++){
      digitalWrite(row[r], LOW);

      for (int c=0; c<6; c++){
        if (digitalRead(col[c]) == LOW){
          Serial.print("\033[2J\033[H");
          Serial.print("Button is pressed");
          Serial.print("ROW:");
          Serial.print(r);
          Serial.print("COLUMN:");
          Serial.print(c);
          Serial.println("Rows and columns start from zero");

          delay(200);
        }
      }

      digitalWrite(row[r], HIGH);
    }
}
